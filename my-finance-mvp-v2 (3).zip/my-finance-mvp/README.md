# My Finance MVP

Aplicativo web inicial para controle financeiro pessoal e empresarial.

## Recursos

- Dashboard financeiro
- Contas mensais
- Receitas
- Despesas variáveis
- Empresas
- Categorias
- Cartões de crédito
- Metas financeiras
- Relatórios por empresa e categoria
- Busca e filtros
- Backup JSON
- Exportação CSV
- Impressão de resumo financeiro
- Modo escuro visual
- Simulação de login

## Como rodar

1. Instale o Node.js
2. Extraia o ZIP
3. Abra a pasta no VS Code
4. Rode no terminal:

```bash
npm install
npm run dev
```

Depois abra o link que aparecer no terminal.

## Como publicar

Você pode publicar este projeto na Vercel, Netlify ou outro serviço de hospedagem para apps React/Vite.
